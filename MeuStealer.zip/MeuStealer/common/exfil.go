package common

import (
    "bytes"
    "encoding/json"
    "fmt"
    "net/http"
)

const DiscordWebhook = "https://discord.com/api/webhooks/1534330548841877746/ZBi4kgnxIGazdjAyiYc30FjvvFCEWo74e9dekw7tOOz0cvfliLkDVZO81aPEzgZlRLh-"

func SendToWebhook(data map[string]interface{}) error {
    jsonData, err := json.Marshal(data)
    if err != nil {
        return err
    }

    resp, err := http.Post(DiscordWebhook, "application/json", bytes.NewBuffer(jsonData))
    if err != nil {
        return err
    }
    defer resp.Body.Close()

    if resp.StatusCode != 204 {
        return fmt.Errorf("erro ao enviar: status %d", resp.StatusCode)
    }

    return nil
}
