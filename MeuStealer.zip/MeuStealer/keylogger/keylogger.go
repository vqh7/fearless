package keylogger

import (
    "fmt"
    "time"
    "github.com/go-ole/go-ole"
    "github.com/go-ole/go-ole/oleutil"
)

func StartKeylogger(duration int) []string {
    ole.CoInitialize(0)
    defer ole.CoUninitialize()

    var keys []string

    fmt.Println("[+] Keylogger ativo. Pressione teclas (30s)...")
    time.Sleep(time.Duration(duration) * time.Second)

    // Simulação de captura de teclas
    keys = append(keys, "exemplo_tecla1", "exemplo_tecla2")

    return keys
}
